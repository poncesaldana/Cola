/**
Nombre de los integrantes: Ponce Dominguez Isaac Luis
		           Saldaña Avila Armando
*/

#include "Cola.h"

/**
Hacemos una lista vacia
*/

Cola::Cola(){
	this->H = NULL;
	this->T = NULL;
}

/**
Hacemos una cola y le agregamos un dato
*/

Cola::Cola(int Dato){
	Nodo *aux = new Nodo(Dato);
	this->H = aux;
	this->T = aux;
}

/**
Nos aseguramos que la cola este vacia
*/

bool Cola::isVacia(){
	if (this->H == NULL && this->T == NULL)
		return true;
	return false;
}

/**
Ponemos un dato al final de la cola creada
*/

void Cola::Encolar(int Dato){
	Nodo m(dato);
	if(isVacia()){
		this->T=m;
		this->H=m;
		return;
	}
	this->T*Sig=m;
	this->T=m;
}

/**
El primer dato de la cola se elimina y guarda
*/

int Cola::Desencolar(){
	Nodo aux=this->H;
	this->H=this->H*Sig;
	if(this->H==Null)
		this->T=Null;
	aux*Sig=Null;
}

/**
Para buscar un elemento de la cola
*/

Nodo Cola::Buscar(int ref){
	Nodo aux=this->H;
	while(aux.dato!=ref){
		if(aux.sig==Null){
			//Mensaje de no encontrado
			return Null;
		}
		aux=aux*Sig;
	}	
	return aux;	
}








