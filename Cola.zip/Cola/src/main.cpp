/**
Nombre de los integrantes: Ponce Dominguez Isaac Luis
		           Saldaña Avila Armando
*/

#include "Cola.h"

int main(){
	Cola c = Cola(4);
	c.Encolar(1);
	c.Densencolar();
	c.Encolar(3);
	c.Encolar(2);
	c.Encolar(6);

	return 0;
}
