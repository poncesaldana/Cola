/**
Nombre de los integrantes: Ponce Dominguez Isaac Luis
		           Saldaña Avila Armando
*/

#include "Nodo.h"

class Cola{

public:
	//Atributos
	Nodo *H;
	Nodo *T;
	//Constructores
	Cola();
	Cola(int Dato);
	//Metodos
	void Encolar(int Dato)
	int Desencolar();
	bool isVacia();
	Buscar();
}
